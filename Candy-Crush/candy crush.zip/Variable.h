/*
 * Variable.h
 *
 *  Created on: Jun 10, 2020
 *      Author: sillpill
 */

#ifndef VARIABLE_H_
#define VARIABLE_H_
#include"Menu.h"
#include"Player.h"
class Variable
{
public:
	Menu A;
	Player B;
	Variable();



};

#endif /* VARIABLE_H_ */
