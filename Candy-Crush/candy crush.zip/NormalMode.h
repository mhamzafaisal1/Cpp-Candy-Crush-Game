/*
 * NormalMode.h
 *
 *  Created on: Jun 8, 2020
 *      Author: sillpill
 */

#ifndef NORMALMODE_H_
#define NORMALMODE_H_
#include"ProgressBar.h"
class NormalMode : public virtual ProgressBar{
public:
	;
void DrawProgressBar();
void ShowTargetMoves();
};

#endif /* NORMALMODE_H_ */
