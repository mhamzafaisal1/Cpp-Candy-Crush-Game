/*
 * TimeMode.cpp
 *
 *  Created on: Jun 8, 2020
 *      Author: sillpill
 */

#include "TimeMode.h"
 void TimeMode::DrawProgressBar(int GemsMatched)
{

}
