/*
 * TimeMode.h
 *
 *  Created on: Jun 8, 2020
 *      Author: sillpill
 */

#ifndef TIMEMODE_H_
#define TIMEMODE_H_
#include"ProgressBar.h"
class TimeMode :public virtual ProgressBar{
public:

 void DrawProgressBar(int GemsMatched);

};

#endif /* TIMEMODE_H_ */
