/*
 * Variable.cpp
 *
 *  Created on: Jun 10, 2020
 *      Author: sillpill
 */


#include"Variable.h"
Variable::Variable()
{

}
