/*
 * AllGmes.h
 *
 *  Created on: Jun 2, 2020
 *      Author: sillpill
 */

#ifndef ALLGEMS_H_
#define ALLGEMS_H_
#include"util.h"

class Gem1{
public:
static void DrawGem(int,int);

};

class Gem2{
public:
static void DrawGem(int,int);

};

class Gem3{
public:
static void DrawGem(int,int);
};

class Gem4{
public:
static void DrawGem(int,int);
};

class Gem5{
public:
static void DrawGem(int,int);
};
class Gem6{
public:
static void DrawGem(int,int);
};
class Gem7{
public:
static void DrawGem(int,int);
};
#include"Gem.h"

#endif /* ALLGEMS_H_ */
